import py5
import serial

sensor = serial.Serial(
    port='/dev/ttyACM0', 
    baudrate=9600,
    timeout=2 # Timeout in seconds for read operations
)

angle = 0.0

triangleVertices = [[130, 120], [180, 120], [155, 360]] # (x1,y1),(x2,y2),(x3,y3)
triangleVertices2 = [[-130, -120], [-180, -120], [-155, -360]] # (x1,y1),(x2,y2),(x3,y3)


def read_data():
    try:
        if sensor.in_waiting > 0:
            data = sensor.readline() # Read until newline, decode, and remove trailing whitespace
            #print(f"Received: {data}")
            return data
    except serial.SerialException as e:
        print(f"Error reading data: {e}")
    return None

def setup():
    py5.size(600, 600)
    py5.smooth()
    global photo
    photo = py5.load_image("compass.png")

def draw():
    global angle
    global triangleVertices
    global triangleVertices2
    
    # Para um segmento entre os pontos \((x_{1},y_{1})\) e \((x_{2},y_{2})\), o ponto médio M é \(((x_{1}+x_{2})/2,(y_{1}+y_{2})/2)\)
    midX = (triangleVertices[0][0] + triangleVertices[1][0]) / 2.0
    midY = (triangleVertices[0][1] + triangleVertices[1][1]) / 2.0

    midX2 = (triangleVertices2[0][0] + triangleVertices2[1][0]) / 2.0
    midY2 = (triangleVertices2[0][1] + triangleVertices2[1][1]) / 2.0

    py5.background(0)
    py5.image(photo, (py5.width/2-300), (py5.height/2-300))
    py5.push_matrix()
    py5.translate(py5.width / 2, py5.height / 2)
    #py5.translate(midX, midY)

    compass_data = read_data()

    if compass_data != None:
       str_decoded = compass_data.decode('utf_8', errors='ignore')
       compass_temp = str_decoded.strip()
       compass_temp = compass_temp.split('/')
       print(f"Received: {compass_temp[0]}")
    
       angle = float(compass_temp[0])

    py5.rotate(py5.radians(angle))

    py5.no_stroke()

    py5.fill(255, 0, 0)

    py5.triangle(triangleVertices[0][0] - midX, triangleVertices[0][1] - midY,
                 triangleVertices[1][0] - midX, triangleVertices[1][1] - midY,
                 triangleVertices[2][0] - midX, triangleVertices[2][1] - midY)
    
    py5.text_size(30)
    py5.fill(0)
    py5.text("N", -9, 60, 101)
    
    py5.fill(0, 76, 153)
    
    py5.triangle(triangleVertices2[0][0] - midX2, triangleVertices2[0][1] - midY2,
                 triangleVertices2[1][0] - midX2, triangleVertices2[1][1] - midY2,
                 triangleVertices2[2][0] - midX2, triangleVertices2[2][1] - midY2)
    
    py5.text_size(30)
    py5.fill(0)
    py5.text("S", -9, -45, -101)

    py5.fill(61, 60, 58)

    py5.circle(0, 0, 35)

    py5.pop_matrix()

    deg = 360.0-angle

    py5.fill(0)

    py5.text_size(20)

    #py5.text("Press (↑) and (↓) to change angle:",30,20);

    py5.text("Heading: " + str(360-deg) + "º",25,35);

def key_pressed():
    global angle

    match py5.key_code:
        case py5.UP:
           print(f"UP PRESSED!") 
           angle += 1
        case py5.DOWN:
           print(f"DOWN PRESSED!")
           angle -= 1

py5.run_sketch()